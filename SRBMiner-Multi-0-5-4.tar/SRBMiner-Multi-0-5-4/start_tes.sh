#!/bin/sh
reset

./SRBMiner-MULTI --algorithm randomkeva --pool kevacoin.herominers.com:10140 --wallet VKz1fvznuaNFY57asDs925Jyn7m9dXWQyM --password x --cpu-threads 0 --disable-gpu 